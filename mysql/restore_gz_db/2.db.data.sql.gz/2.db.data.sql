--
-- Dumping data for table `users`
--

INSERT INTO `users` VALUES (1,'exampleuser1','$apr1$llKJEzNr$NFKu2uDwvNx6n2qPalkF01');
INSERT INTO `users` VALUES (2,'exampleuser2','$apr1$OTpT.BkV$lHU9Sviy82RqZP5cD.Cuo.');
